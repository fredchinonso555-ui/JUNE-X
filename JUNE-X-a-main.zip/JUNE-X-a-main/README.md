
<div align="center"> 
<strong>JUNE X </strong>
    <br>
  <a href="https://git.io/typing-svg"> 
    <img src="https://readme-typing-svg.demolab.com?font=Rockwell&size=50&pause=1000&color=33ff00&center=true&width=910&height=100&lines=June-Official;Multi+Device+Whatsapp+Bot;Made+by+supreme" alt="Typing SVG" />
  </a> 
</div> 

<div align="center"> 
  <a href=""> 
    <img src="https://files.catbox.moe/pr5ynj.jpg" alt="JUNE X" height="300"> 
  </a> 
</div>

[![Typing SVG](https://readme-typing-svg.demolab.com/?lines=the+bot+supports+deployment;on+all+free+panels+easily)](https://git.io/typing-svg)

<div align="center">    
<strong> DEPLOY JUNE-X </strong>
    <br>
  <a href="https://auth-ivory-delta.vercel.app/">
    <img src="https://img.shields.io/badge/Deploy%20June-100000?style=for-the-badge&logo=scan&logoColor=white&labelColor=darkblue&color=darkgreen" alt="FORK REPO"/>
  </a>
</div>

<br>
<div align="center">
<strong> SESSION PAIRS </strong>
    <br>
  <a href="https://pair-2-63169a32ae4e.herokuapp.com/pair" target="_blank">
    <img src="https://img.shields.io/badge/pair %20code 1-100000?style=for-the-badge&logo=scan&logoColor=white&labelColor=darkblue&color=darkred" alt="PAIR"/>
  </a>
</div>
<br>
<p align="center">
    <a href="https://junexsession.onrender.com/pair" target="_blank">
        <img alt="Download zip" src="https://img.shields.io/badge/PAIR CODE%20 2-100000?style=for-the-badge&logo=scan&logoColor=white&labelColor=darkorange&color=darkorange"/>
    </a>
</p>


<p align="center">
    <a href="https://junexsession.onrender.com/qr" target="_blank">
        <img alt="Download zip" src="https://img.shields.io/badge/PAIR QR CODE%20 -100000?style=for-the-badge&logo=scan&logoColor=white&labelColor=darkorange&color=purple"/>
    </a>
</p>


<p align="center">  
<strong> DOWNLOAD ZIP </strong>
    <br>
    <a href="https://codeload.github.com/vinpink2/JUNE-X/zip/refs/heads/main" target="_blank">
        <img alt="Download zip" src="https://img.shields.io/badge/DOWNLOAD%20 ZIP-100000?style=for-the-badge&logo=scan&logoColor=white&labelColor=darkorange&color=darkblue"/>
    </a>
</p>



    



